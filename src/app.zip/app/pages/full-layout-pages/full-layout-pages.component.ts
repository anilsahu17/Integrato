import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-full-layout-pages',
  templateUrl: './full-layout-pages.component.html',
  styleUrls: ['./full-layout-pages.component.scss']
})
export class FullLayoutPagesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
