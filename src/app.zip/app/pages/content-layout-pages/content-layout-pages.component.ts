import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-content-layout-pages',
  templateUrl: './content-layout-pages.component.html',
  styleUrls: ['./content-layout-pages.component.scss']
})
export class ContentLayoutPagesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
